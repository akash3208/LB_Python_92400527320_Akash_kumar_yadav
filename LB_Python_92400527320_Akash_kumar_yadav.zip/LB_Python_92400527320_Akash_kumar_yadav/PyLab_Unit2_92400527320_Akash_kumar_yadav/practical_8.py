# Marks of 4 subjects
m=[int(input()) for _ in range(4)]
t=sum(m); p=t/4
print(t); print(p)
print('FAIL' if min(m)<40 else 'PASS')
