# Age category
age=int(input())
if age<12: print('You are Kid')
elif age<=17: print('You are teenager')
elif age<=60: print('You are Adult')
else: print('You are Senior Citizen')
