# Prime numbers 1 to 100
for n in range(2,101):
    f=True
    for i in range(2,n):
        if n%i==0: f=False; break
    if f: print(n)
