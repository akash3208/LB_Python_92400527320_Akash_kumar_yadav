# Prime or not
n=int(input()); flag=n>1
for i in range(2,n):
    if n%i==0: flag=False; break
print('Prime' if flag else 'Not Prime')
