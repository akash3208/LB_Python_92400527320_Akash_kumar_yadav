# Word frequency count
text=input().split(); d={}
for w in text: d[w]=d.get(w,0)+1
for k in sorted(d): print(k, d[k])
