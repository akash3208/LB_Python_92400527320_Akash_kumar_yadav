# Function accepts 3 arguments
def calculate(a,b,op):
    if op=='+': return a+b
    if op=='-': return a-b
    if op=='*': return a*b
    if op=='/': return a/b
print(calculate(int(input()),int(input()),input()))
