# Read names from keyboard and store into text file
f=open('names.txt','w')
n=int(input())
for _ in range(n): f.write(input()+'\n')
f.close()
