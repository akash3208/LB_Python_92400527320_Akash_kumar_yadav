# Read numbers from file and display total and average
f=open('numbers.txt','r')
a=[int(x.strip()) for x in f]
print(sum(a)); print(sum(a)/len(a))
f.close()
