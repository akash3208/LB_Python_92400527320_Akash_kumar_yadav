# Box Plot
import matplotlib.pyplot as plt
data=[12,15,14,10,18,20,22,25,30,28,35,40]
plt.boxplot(data,notch=True,showmeans=True)
plt.title('Box Plot'); plt.show()
