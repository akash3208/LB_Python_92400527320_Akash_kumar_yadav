# Line Plot
import matplotlib.pyplot as plt
plt.plot([1,2,3,4],[10,20,15,25],marker='o')
plt.title('Line Plot'); plt.show()
