# Write a simple Python Program to INPUT two variables and print Addition, Subtraction, Multiplication and Division of both numbers.
a=int(input('Enter first number: '))
b=int(input('Enter second number: '))
print(a+b) ; print(a-b) ; print(a*b) ; print(a/b)
