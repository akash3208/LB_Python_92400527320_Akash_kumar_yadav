# Write a program to input Principal Amount, Rate and Year and display Compound Interest
p=float(input()); r=float(input()); t=float(input()); print(p*((1+r/100)**t)-p)
